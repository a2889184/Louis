There are four file in CA1051_b01504044
fac.txt: the source code of the factorial calculator
hw2.jpg: screenshot of the result computed by the calculator
reportCA_hw2.pdf: report of hw2
README.txt: this file

------------------------------------------------------------------------------------------------
You can use QtSpim to open fac.txt and run the factorial calculator

1. Run QtSpim.
2. Click File -> Reinitialize and Load File, and then open "CA1051_b01504044/fac.txt".
3. Click Run/Continue(Icon in the bar) to run the program, and then follow the instructions appear in the console.
4. If you want to re-run the program, click Clear Registers(Icon in the bar), and redo step 3.


If there are any mistake in any of the file, feel free to contact me: b01504044@ntu.edu.tw / YI LIN, SUNG.